import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Route, Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [ReactiveFormsModule,RouterLink],
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css'
})
export class RegistrationComponent {

  countries : any[] = [];
  states:any[] = [];
  roles:any[] = [];

  selectedFile:File | null = null;

  constructor(private authapi : AuthService,private router:Router){}

  regsitrationForm = new FormGroup({
    firstName: new FormControl("",[Validators.required]),
    lastName: new FormControl("",[Validators.required]),
    email: new FormControl("",[Validators.required,Validators.email]),
    dob : new FormControl('',[Validators.required]),
    mobile:new FormControl('',[Validators.required]),
    userType: new FormControl("",[Validators.required]),
    countryId: new FormControl("",[Validators.required]),
    stateId: new FormControl("",[Validators.required]),
    zipcode: new FormControl("",[Validators.required]),
    addressLine1: new FormControl(""),
    addressLine2: new FormControl(""),
    })

    showCountries(){
    this.authapi.getCountries().subscribe((data:any)=>{
      this.countries = data;
      })
    }

    showStates(event : any){
    this.authapi.getStates(event.target.value).subscribe((data:any) =>{
      this.states = data; 
      })
    }

    showRoles(){
      this.authapi.getRoles().subscribe((data:any)=>{
        this.roles = data;
      })
    }

    onFileChanged(event: any) {
      const file = event.target.files[0];
      if (file) {
        this.selectedFile = file;
      }
    }

    onSubmit(){
      console.log(this.regsitrationForm.value);
      
      if (this.regsitrationForm.valid && this.selectedFile) {
      const formData = new FormData();
      Object.keys(this.regsitrationForm.value).forEach((key) => {
        formData.append(key, this.regsitrationForm.get(key)?.value || '');
      });
      formData.append('profileImage', this.selectedFile);

      this.authapi.registerUser(formData).subscribe((data:any)=>{
        alert('registration successful');
        this.router.navigate(['/login'])
      });
    }
  }


    get FirstName() : FormControl{
      return this.regsitrationForm.get('firstName') as FormControl;
    } 
    get LastName() : FormControl{
      return this.regsitrationForm.get('lastName') as FormControl;
    } 
    get Email() : FormControl{
      return this.regsitrationForm.get('email') as FormControl;
    } 
    get Dob() : FormControl{
      return this.regsitrationForm.get('dob') as FormControl;
    } 

    get Mobile() : FormControl{
      return this.regsitrationForm.get('mobile') as FormControl;
    }
    get Country() : FormControl{
      return this.regsitrationForm.get('countryId') as FormControl;
    }
    get State() : FormControl{
      return this.regsitrationForm.get('stateId') as FormControl;
    }
    get Zipcode() : FormControl{
      return this.regsitrationForm.get('zipcode') as FormControl;
    }
  
    get Role() : FormControl{
      return this.regsitrationForm.get('userType') as FormControl;
    } 

}

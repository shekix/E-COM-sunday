import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { RouterLink, RouterOutlet } from '@angular/router';
import { ProfileComponent } from "../profile/profile.component";


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterOutlet, RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
pfp:any;
username = sessionStorage.getItem('username');
userinfo:any;
constructor(private userSerice:UserService){}

ngOnInit(): void {
    this.userSerice.getUser(this.username).subscribe((data:any)=>{
    this.userinfo = data;
    console.log(data);
    this.pfp = "https://localhost:7051"+this.userinfo.profileImage
    })
}


}

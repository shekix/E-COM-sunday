import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import * as bootstrap from 'bootstrap';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule,RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {


  otpError : string = "";

  jwtHelperService = new JwtHelperService();

  constructor(private authApi:AuthService,private router:Router){

  }

  loginForm = new FormGroup({
    username : new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required]),
  })

  otpForm = new FormGroup({
    otp:new FormControl('', [Validators.required])
  })

  forgotPasswordForm = new FormGroup({
    email:new FormControl('',[Validators.required,Validators.email])
  })


  onLogin(){
    var data = {... this.loginForm.value}
    this.authApi.loginUser(data).subscribe({
      next: (response: any) => {
        const otpModal = new bootstrap.Modal(document.getElementById('otpModal')!);
        otpModal.show();
        sessionStorage.setItem("username",data.username!=null?data.username:"");
      },
      error: (error) => {
        if (error.status === 401) {
          alert('Invalid username or password.')
        } else {
          alert('An unexpected error occurred. Please try again later.')
          console.log(error);
          
        }
      },
    });
  }

  verifyOtp(){
    var data = {
      username:sessionStorage.getItem('username'),
      otp:this.otpForm.value.otp
    }
    this.authApi.verifyOtp(data).subscribe({
      next: (response: any) => {
        const otpModal = bootstrap.Modal.getInstance(document.getElementById('otpModal')!);
        otpModal?.hide();
        sessionStorage.setItem("token",response);
        this.loadCurrentUser();
        this.router.navigate(['/home']);
      },
      error: (error) => {
        if (error.status === 400) {
          this.otpError = 'Invalid OTP. Please try again.'
        } else {
          alert('An unexpected error occurred. Please try again later.')
        }
      },
    })
  }


  loadCurrentUser(){
    const token = sessionStorage.getItem("token");
    const userInfo = token != null? this.jwtHelperService.decodeToken(token) : null;
    const data = userInfo ? {
      username:userInfo["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"],
      role:userInfo["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"],
      userid:userInfo["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"]
    }:null;
    sessionStorage.setItem("name",data?.username)
    sessionStorage.setItem("role",data?.role);
    sessionStorage.setItem("id",data?.userid);
  }

  openForgotPasswordModal() {
    const modalElement = document.getElementById('forgotPasswordModal');
    if (modalElement) {
      const forgotPasswordModal = new bootstrap.Modal(modalElement);
      forgotPasswordModal.show();
    }
  }


  submitForgotPassword()
  {
    const data = this.forgotPasswordForm.value.email
    
    this.authApi.forgotPass(data).subscribe({
      next: (response: any) => {
        const forgotPasswordModal = bootstrap.Modal.getInstance(document.getElementById('forgotPasswordModal')!);
        forgotPasswordModal?.hide();
        alert('check mail');
      },
      error: (error) => {
        if (error.status === 404) {
          alert('email does not exists');
        } else {
          alert('An unexpected error occurred. Please try again later.')
        }
      },
    })
  }


  get Username() : FormControl{
    return this.loginForm.get('username') as FormControl;
  } 
  get Password() : FormControl{
    return this.loginForm.get('password') as FormControl;
  } 

  get Otp():FormControl {
    return this.otpForm.get('otp') as FormControl
  }

}

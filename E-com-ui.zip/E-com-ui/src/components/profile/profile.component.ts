import { Component, Input } from '@angular/core';
import { UserService } from '../../services/user.service';
import { AuthService } from '../../services/auth.service';
import { DatePipe, formatDate, NgFor, NgIf } from '@angular/common';
import { FormControl, FormGroup, FormsModule, NgModel, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [DatePipe,FormsModule,ReactiveFormsModule,NgFor,NgIf],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {

  userinfo:any;
  pfp:any;
  username = sessionStorage.getItem('username');

  countries : any[] = [];
  states:any[] = [];

  selectedFile:File | null = null;

  constructor(private authapi : AuthService,private router:Router,private userService:UserService){}

  regsitrationForm = new FormGroup({
    username: new FormControl(this.username),
    firstName: new FormControl("",[Validators.required]),
    lastName: new FormControl("",[Validators.required]),
    email: new FormControl("",[Validators.required,Validators.email]),
    dob : new FormControl('',[Validators.required]),
    mobile:new FormControl('',[Validators.required]),
    countryId: new FormControl("",[Validators.required]),
    stateId: new FormControl("",[Validators.required]),
    zipcode: new FormControl("",[Validators.required]),
    addressLine1: new FormControl(""),
    addressLine2: new FormControl(""),
    })

    ngOnInit(){
      this.userService.getUser(this.username).subscribe((data:any)=>{
      this.userinfo = data;

      this.pfp = "https://localhost:7051"+this.userinfo.profileImage;

      this.showCountries();
      this.showStatesbyId(this.userinfo.countryId)

      this.regsitrationForm.patchValue({
        firstName: this.userinfo.firstName,
        lastName: this.userinfo.lastName,
        email: this.userinfo.email,
        dob: formatDate(this.userinfo.dob,"yyyy-MM-dd","en"),
        mobile: this.userinfo.mobile,
        countryId: this.userinfo.countryId,
        stateId: this.userinfo.stateId,
        zipcode: this.userinfo.zipcode,
        addressLine1: this.userinfo.addressLine1,
        addressLine2: this.userinfo.addressLine2,
      });
    })
  }

    showCountries(){
      this.authapi.getCountries().subscribe((data:any)=>{
        this.countries = data;
        })
      }

      showStatesbyId(id:any){
        this.authapi.getStates(id).subscribe((data:any) =>{
          this.states = data; 
          })
      }
  
      showStates(event : any ){
      this.authapi.getStates(event.target.value).subscribe((data:any) =>{
        this.states = data; 
        })
      }

      onFileChanged(event: any) {
        const file = event.target.files[0];
        if (file) {
          this.selectedFile = file;
        }
      }

      onSubmit(){
        console.log(this.regsitrationForm.value);
        
        if (this.regsitrationForm.valid ) {
        const formData = new FormData();
        Object.keys(this.regsitrationForm.value).forEach((key) => {
          formData.append(key, this.regsitrationForm.get(key)?.value || '');
        });
        formData.append('profileImage', this.selectedFile!);
  
        this.userService.updateUser(formData).subscribe((data:any)=>{
          alert('user updated');
        });
      }
    }

    get FirstName() : FormControl{
      return this.regsitrationForm.get('firstName') as FormControl;
    } 
    get LastName() : FormControl{
      return this.regsitrationForm.get('lastName') as FormControl;
    } 
    get Email() : FormControl{
      return this.regsitrationForm.get('email') as FormControl;
    } 
    get Dob() : FormControl{
      return this.regsitrationForm.get('dob') as FormControl;
    } 

    get Mobile() : FormControl{
      return this.regsitrationForm.get('mobile') as FormControl;
    }
    get Country() : FormControl{
      return this.regsitrationForm.get('countryId') as FormControl;
    }
    get State() : FormControl{
      return this.regsitrationForm.get('stateId') as FormControl;
    }
    get Zipcode() : FormControl{
      return this.regsitrationForm.get('zipcode') as FormControl;
    }
  

}

﻿using Infrastructure.Database;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace E_commerce_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryStateController : ControllerBase
    {
        private readonly AppDbContext _context;
        public CountryStateController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("country")]
        public async Task<IActionResult> countries()
        {
            var countries = await _context.Countries.ToListAsync();
            return Ok(countries);
        }

        [HttpGet("states")]
        public async Task<IActionResult> statesById(int id)
        {
            var states = await _context.States.Where( s => s.CountryId == id).ToListAsync();
            return Ok(states);
        }
    }
}
